// import React from 'react';
// import ReactDOM from 'react-dom';
import PhotoCarousel from './components/PhotoCarousel';
// import './styles/style.css';

window.PhotoCarousel = PhotoCarousel;
